;(function(){
	var body = document.getElementsByTagName("html")[0];
	body.style.fontSize = body.offsetWidth/(375/16)+"px";
})();

window.onresize = function(){
	var body = document.getElementsByTagName("html")[0];
	body.style.fontSize = body.offsetWidth/(375/16)+"px";
}